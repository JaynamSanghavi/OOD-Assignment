package com.example.reusebook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReuseBookApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReuseBookApplication.class, args);
    }

}
